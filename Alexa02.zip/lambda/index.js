// This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
// Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
// session persistence, api calls, and more.

//Librerías
const Alexa = require('ask-sdk-core');

// Constantes
const BIENVENIDA_MSG = 'Te doy la bienvenida a Feliz Cumpleaños. ¡Vamos a divertirnos un poco con tu cumpleaños!';
const AYUDA_MSG = 'Puedes decirme el día, mes y año de tu nacimiento y tomaré nota de ello. También puedes decirme, registra mi cumpleaños y te guiaré. ¿Qué quieres hacer?';
const ADIOS_MSG = '¡Hasta luego';
const FALLBACK_MSG = 'Lo siento, no se nada sobre eso. Por favor inténtalo otra vez.';
const RECHAZADO_MSG = 'No pasa nada. Por favor dime la fecha otra vez y lo corregimos.';

// Lanzamineto
const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    handle(handlerInput) {
        const speakOutput = BIENVENIDA_MSG;
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt(speakOutput)
             // usamos este evento para disparar el evento que queremos sin esperar
            .addDelegateDirective({
                name: 'RegistrarCumpleIntentHandler',
                confirmationStatus: 'NONE',
                slots: {}
            })
            .getResponse();
    }
};


const RegistrarCumpleIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'RegistrarCumpleIntent';
    },
    handle(handlerInput) {
        // Obtenemos el hadler de entrada y salida
        const {requestEnvelope, responseBuilder} = handlerInput;
        // Obtenemos el Intent a través del HandlerInput
        const {intent} = requestEnvelope.request;
        
        let speakOutput = RECHAZADO_MSG;
        
        //Si nos han llegado las cosas
        //if (intent.confirmationStatus === 'CONFIRMED') {
            //Almacenamos
            const dia = Alexa.getSlotValue(requestEnvelope, 'dia');
            const anno = Alexa.getSlotValue(requestEnvelope, 'anno');
            const mes = Alexa.getSlotValue(requestEnvelope, 'mes');
       
            // Luego veremos como hacerlo más fácil
            // Construimos la salida concatenando
            //const speakOutput = 'Tu fecha de cumpleaños es el día '+ dia +' del mes de ' + mes +' de ' + anno;
            // Otra manera, parametrizada
            speakOutput = `Tu fecha de cumpleaños es el ${dia} de ${mes} de ${anno}`;
        //}else{
        //    // Si no mostramos mensaje de ayuda
        //    speakOutput = AYUDA_MSG;
        //    responseBuilder.reprompt(speakOutput);
        //}
        
        return responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};
const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speakOutput = AYUDA_MSG;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};
const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = ADIOS_MSG; 
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};

// Se dispara cuando un cliente dice algo que no se asigna a ninguna intención 
const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
        const speechText = handlerInput.t('FALLBACK_MSG');

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(AYUDA_MSG)
            .getResponse();
    }
};

const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse();
    }
};

// The intent reflector is used for interaction model testing and debugging.
// It will simply repeat the intent the user said. You can create custom handlers
// for your intents by defining them above, then also adding them to the request
// handler chain below.
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `You just triggered ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};

// Generic error handling to capture any syntax or routing errors. If you receive an error
// stating the request handler chain is not found, you have not implemented a handler for
// the intent being invoked or included it in the skill builder below.
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        console.log(`~~~~ Error handled: ${error.stack}`);
        const speakOutput = `Sorry, I had trouble doing what you asked. Please try again.`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

// This request interceptor will log all incoming requests to this lambda
const LoggingRequestInterceptor = {
    process(handlerInput) {
        console.log(`Incoming request: ${JSON.stringify(handlerInput.requestEnvelope)}`);
    }
};

// This response interceptor will log all outgoing responses of this lambda
const LoggingResponseInterceptor = {
    process(handlerInput, response) {
        console.log(`Outgoing response: ${JSON.stringify(response)}`);
    }
};

// The SkillBuilder acts as the entry point for your skill, routing all request and response
// payloads to the handlers above. Make sure any new handlers or interceptors you've
// defined are included below. The order matters - they're processed top to bottom.
exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        RegistrarCumpleIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        FallbackIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler, // make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers
    )
    .addErrorHandlers(
        ErrorHandler,
    )
    .addRequestInterceptors(
        LoggingRequestInterceptor
        )
    .addResponseInterceptors(
        LoggingResponseInterceptor
        )
    .lambda();

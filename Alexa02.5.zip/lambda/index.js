
// LIBRERÍAS
const Alexa = require('ask-sdk-core');
// i18n librería para usar el interceptor de localización para poder tener los mensajes en distintos idiomas.
const i18n = require('i18next');

// CONSTANTES
//Creamos un objeto de cadenas de lenguaje que contiene todas nuestras cadenas.
//Las claves para cada cadena se referenciarán en nuestro código, p. handlerInput.t ('WELCOME_MSG')
 const languageStrings = {
    es: {
        translation: {
            WELCOME_MSG: 'Te doy la bienvenida a Feliz Cumpleaños. ¡Vamos a divertirnos un poco con tu cumpleaños! ',
            REGISTER_MSG: 'Tu fecha de cumpleaños es el {{dia}} de {{mes}} de {{anno}}.',
            REJECTED_MSG: 'No pasa nada. Por favor dime la fecha otra vez y lo corregimos.',
            HELP_MSG: 'Puedes decirme el día, mes y año de tu nacimiento y tomaré nota de ello. También puedes decirme, registra mi cumpleaños y te guiaré. ¿Qué quieres hacer?',
            GOODBYE_MSG: '¡Hasta luego!',
            REFLECTOR_MSG: 'Acabas de activar {{intent}}',
            FALLBACK_MSG: 'Lo siento, no se nada sobre eso. Por favor inténtalo otra vez.',
            ERROR_MSG: 'Lo siento, ha habido un problema. Por favor inténtalo otra vez.'
        }
    }
}

//LANZAMIENTO - INTENCION
const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    // Proceso
    handle(handlerInput) {
        const mensaje = handlerInput.t('WELCOME_MSG');
        
        return handlerInput.responseBuilder
            .speak(mensaje)
            // usamos el encadenamiento de intenciones para activar el registro de cumpleaños en varios usos seguidos
            .addDelegateDirective({
                name: 'RegistrarCumpleIntent',
                confirmationStatus: 'NONE',
                slots: {}
            })
            .getResponse();
    }
};

// REGISTRAR CUMPLEAÑOS - INTENCION
const RegistrarCumpleIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'RegistrarCumpleIntent';
    },
    //Proceso
    handle(handlerInput) {
        // Recogemos los la entrada entrada - handler Input
        const {requestEnvelope, responseBuilder} = handlerInput;
        // Tomamos su intención y con ello la estructura de datos donde nos llega los slots
        const {intent} = requestEnvelope.request;
        // Creamos mensaje
        let mensaje = handlerInput.t('REJECTED_MSG');
        // Si todo esta confirmado
        //if (intent.confirmationStatus === 'CONFIRMED') {
            //Tomamos los slots y los almacenamos en variables
            const dia = Alexa.getSlotValue(requestEnvelope, 'dia');
            const mes = Alexa.getSlotValue(requestEnvelope, 'mes');
            const anno = Alexa.getSlotValue(requestEnvelope, 'anno');
            // Creamos la salida, pasamos las variables a los campos parametrizados (clave-valor) para crear el mensaje
            mensaje = handlerInput.t('REGISTER_MSG', {dia: dia, mes: mes, anno: anno}); // we'll save these values in the next module
       // } else {
            // Mensaje de repront, es decir, volver a pedir lo que diría este intent pero con otras palabras, es decir, otro intento
         //   const repromptText = handlerInput.t('HELP_MSG');
         //   responseBuilder.reprompt(repromptText);
    //    }
        // Devolvemos la salida
        return responseBuilder
            .speak(mensaje)
            .getResponse();
    }
};

// AYUDA - INTENT
const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const mensaje = handlerInput.t('HELP_MSG');

        return handlerInput.responseBuilder
            .speak(mensaje)
            .reprompt(mensaje)
            .getResponse();
    }
};

// CANCELACIÓN Y PARADA INTENT
const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const mensaje = handlerInput.t('GOODBYE_MSG');

        return handlerInput.responseBuilder
            .speak(mensaje)
            .getResponse();
    }
};


// FallbackIntent se activa cuando un cliente dice algo que no se asigna a ninguna intención en su habilidad
// También debe definirse en el modelo de idioma (si la configuración regional lo admite)
//Este controlador se puede agregar de forma segura, pero se ignorará en las configuraciones regionales que aún no lo admiten
const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
        const mensaje = handlerInput.t('FALLBACK_MSG');

        return handlerInput.responseBuilder
            .speak(mensaje)
            .reprompt(handlerInput.t('HELP_MSG'))
            .getResponse();
    }
};

// SessionEndedRequest notifica que una sesión ha finalizado. Este controlador se activará cuando se abra actualmente
// la sesión se cierra por uno de los siguientes motivos: 1) El usuario dice "salir" o "salir". 2) El usuario no
// responde o dice algo que no coincide con una intención definida en su modelo de voz. 3) se produce un error
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`~~~~ Session ended: ${JSON.stringify(handlerInput.requestEnvelope)}`);
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse(); // notice we send an empty response
    }
};


// Intent reflector se utiliza para probar y depurar modelos de interacción.
// Simplemente repetirá la intención que dijo el usuario. Puedes crear manejadores personalizados para tus intentos
// definiéndolos arriba, luego también agregándolos a la cadena de manejador de solicitudes a continuación
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speechText = handlerInput.t('REFLECTOR_MSG', {intent: intentName});

        return handlerInput.responseBuilder
            .speak(speechText)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};

// Generic error para capturar cualquier errores de sintaxis o errores de enrutamiento. Si recibes un error
// indicando que no se encuentra la cadena del controlador de solicitudes, no ha implementado un controlador para
// la intención invocada o incluida en el generador de habilidades a continuación
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const speechText = handlerInput.t('ERROR_MSG');
        console.log(`~~~~ Error handled: ${JSON.stringify(error)}`);

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(handlerInput.t('HELP_MSG'))
            .getResponse();
    }
};

// Request interceptor registrará todas las solicitudes entrantes en esta lambda
const LoggingRequestInterceptor = {
    process(handlerInput) {
        console.log(`Incoming request: ${JSON.stringify(handlerInput.requestEnvelope)}`);
    }
};

// Response interceptor registrará todas las respuestas salientes de esta lambda
const LoggingResponseInterceptor = {
    process(handlerInput, response) {
        console.log(`Outgoing response: ${JSON.stringify(response)}`);
    }
};

// Este Request interceptor enlazará una función de traducción 't' al controlador de entrada
const LocalisationRequestInterceptor = {
    process(handlerInput) {
        i18n.init({
            lng: Alexa.getLocale(handlerInput.requestEnvelope),
            resources: languageStrings
        }).then((t) => {
            handlerInput.t = (...args) => t(...args);
        });
    }
};



// Este controlador (handler) actúa como el punto de entrada para la skill, enrutando todas las solicitudes y respuestas
// a los controladores anteriores. Todos deben estar definidos o incluídos aquí. El orden importa: se procesan de arriba a abajo
exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
       RegistrarCumpleIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        FallbackIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler)
    .addErrorHandlers(
        ErrorHandler)
    .addRequestInterceptors(
        LocalisationRequestInterceptor,
        LoggingRequestInterceptor)
    .addResponseInterceptors(
        LoggingResponseInterceptor)
    //.withCustomUserAgent('sample/happy-birthday/mod3')
    .lambda();

// CONSTANTES
//Creamos un objeto de cadenas de lenguaje que contiene todas nuestras cadenas.
//Las claves para cada cadena se referenciarán en nuestro código, p. handlerInput.t ('WELCOME_MSG')

module.exports = {
    es: {
        translation: {
            WELCOME_MSG: 'Te doy la bienvenida a Feliz Cumpleaños. ¡Vamos a divertirnos un poco con tu cumpleaños! ',
            WELCOME_BACK_MSG: 'Te doy la bienvenida otra vez! ',
            REJECTED_MSG: 'No pasa nada. Por favor dime la fecha otra vez y lo corregimos. ',
            REGISTER_MSG: 'Recordaré que tu fecha de cumpleaños es el {{dia}} de {{mes}} de {{anno}}.',
            DAYS_LEFT_MSG: 'Queda {{contador}} día ',
            DAYS_LEFT_MSG_plural: 'Quedan {{contador}} días ',
            WILL_TURN_MSG: 'para que cumplas {{contador}} años. ',
            WILL_TURN_MSG_plural: 'para que cumplas {{contador}} años. ',
            GREET_MSG: '¡Feliz cumpleaños!. ¡Hoy cumples {{contador}} años! ',
            GREET_MSG_plural: '¡Feliz cumpleaños!. ¡Hoy cumples {{contador}} años! ',
            MISSING_MSG: 'Parece que aun no me has dicho tu fecha de cumpleaños. ',
            POST_SAY_HELP_MSG: 'Si quieres cambiar la fecha puedes decir, registra mi cumpleaños. O sólo dime la fecha directamente. ¿Qué quieres hacer? ',
            HELP_MSG: 'Puedo recordar tu cumpleaños si me dices una fecha. O decirte cuanto falta para que cumplas. ¿Qué quieres hacer? ',
            REPROMPT_MSG: 'Si no sabes como continuar intent pedir ayuda. Si quieres salir solo dí para. ¿Qué quieres hacer? ',
            GOODBYE_MSG: '¡Hasta luego! ',
            REFLECTOR_MSG: 'Acabas de activar {{intent}}',
            FALLBACK_MSG: 'Lo siento, no se nada sobre eso. Por favor inténtalo otra vez. ',
            ERROR_MSG: 'Lo siento, ha habido un problema. Por favor inténtalo otra vez. '
        }
    }
}